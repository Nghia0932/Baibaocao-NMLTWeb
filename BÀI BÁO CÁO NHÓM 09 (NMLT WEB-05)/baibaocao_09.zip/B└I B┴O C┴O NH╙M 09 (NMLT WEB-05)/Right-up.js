$(document).ready(function() {
    $('#Right #Right-up').slick({
        centerPadding: '5px',
        slidesToShow: 2,
        arrows: false,
        autoplay: true,
        autoplaySpeed: 1000,
        infinite: true,
    });
});